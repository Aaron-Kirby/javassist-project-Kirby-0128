package main;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.Loader;
import javassist.NotFoundException;

public class ModLoader {

	private static final String PKG_NAME = "target" + ".";
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] classList;
		String[] methodList;
		ArrayList<String> methodAlreadyModded = new ArrayList<String>();
		boolean check = false;
		
		do {
			System.out.println("Please enter three class names separated by commas (Point, Rectangle, or Circle).\n"
					+ "Key \"q\" to quit.");
			String input = sc.nextLine();
			classList = input.split(",");
			for (int i = 0; i < classList.length; i++) {
				classList[i] = classList[i].trim();
				if (classList[i].equals("q")) {
					System.out.println("You have quit the program.");
					System.exit(0);
				}
			}

			if (classList.length != 3) {
				System.out.println("[WRN] Invalid Input size!!");
				for (int i = 0; i < classList.length; i++) {
					classList[i] = null;
				}
			} else {
				check = true;
			}
		} while (!check);
		check = false;

		try {
			for(int i = 0; i < classList.length; i++) {
				classList[i] = PKG_NAME + classList[i];
			}
			
			ClassPool pool = ClassPool.getDefault();
			CtClass sup = pool.get(classList[0]);
			CtClass sub1 = pool.get(classList[1]);
			CtClass sub2 = pool.get(classList[2]);
			
			setSuperclass(sub1, classList[0], pool);
			setSuperclass(sub2, classList[0], pool);
			System.out.println("===========================================================");
			System.out.println("");
			
			do {
				System.out.println("Please enter a usage method (add or remove),\n"
						+ "an increment method (incX or incY),\n"
						+ "and a getter method (getX or or getY)--all separated by commas.\n"
						+ "Key \"q\" to quit.");
				String input = sc.nextLine();
				methodList = input.split(",");
				for (int i = 0; i < methodList.length; i++) {
					methodList[i] = methodList[i].trim();
					if (methodList[i].equals("q")) {
						System.out.println("You have quit the program.");
						System.exit(0);
					}
				}

				if (methodList.length != 3) {
					System.out.println("[WRN] Invalid Input size!!");
					for (int i = 0; i < methodList.length; i++) {
						methodList[i] = null;
					}
				} 
				else if (methodAlreadyModded.contains(methodList[0])) {
					System.out.println("[WRN] This method " + methodList[0] + " has been modified!!");
					for (int i = 0; i < methodList.length; i++) {
						methodList[i] = null;
					}
				}
				else {
					editMethod(sub1, methodList[0], methodList[1], methodList[2]);
					editMethod(sub2, methodList[0], methodList[1], methodList[2]);
					
					Loader load = new Loader(pool);
					Class<?> sbc1 = load.loadClass(classList[1]);
					Class<?> sbc2 = load.loadClass(classList[2]);
					
					Object obj1 = sbc1.newInstance();
					Object obj2 = sbc2.newInstance();
					
					Class<?> obj1class = obj1.getClass();	
					Class<?> obj2class = obj2.getClass();
					
					Method mtest1 = obj1class.getDeclaredMethod(methodList[0], new Class[] {});
					Method mtest2 = obj2class.getDeclaredMethod(methodList[0], new Class[] {});
					
					System.out.println("Calling modded method " + methodList[0] + " of " + classList[1]);
			        Object invoker1 = mtest1.invoke(obj1, new Object[] {});
					
			        System.out.println("Calling modded method " + methodList[0] + " of " + classList[2]);
			        Object invoker2 = mtest2.invoke(obj2, new Object[] {});
			        
					methodAlreadyModded.add(methodList[0]);
					System.out.println("");
				}
			} while (!check);
				
		} catch(NotFoundException | CannotCompileException | ClassNotFoundException 
				| IllegalAccessException | InstantiationException | NoSuchMethodException
				| InvocationTargetException e) {
			e.printStackTrace();
		}
	}

	// Adds superclass to the given class
	static void setSuperclass(CtClass curClass, String superClass, ClassPool pool)
			throws NotFoundException, CannotCompileException {
		curClass.defrost();
		curClass.setSuperclass(pool.get(superClass));
		System.out.println("[DBG] set superclass: " + curClass.getSuperclass().getName() + //
				", subclass: " + curClass.getName());
	}
	
	static void editMethod(CtClass cn, String useMethod, String incMethod, String getMethod) 
			throws NotFoundException, CannotCompileException {
		cn.defrost();
		CtMethod m1 = cn.getDeclaredMethod(useMethod);
		char varc = incMethod.charAt(3);
		
		m1.insertBefore("{ " + 
				incMethod + "(); " +
				"System.out.println(\"" + varc + ": \" + " + getMethod + "()); " +
				" }" 
				);
		
		
	}
}